package com.example.phream.phream.model.database;

public class Database {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "phream.db";
}